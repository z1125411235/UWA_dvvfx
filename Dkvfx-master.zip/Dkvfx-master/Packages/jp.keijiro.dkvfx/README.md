Dkvfx
-----

![Screenshot](https://i.imgur.com/FZy60GMl.jpg)

This is a Unity sample project that shows how to integrate a volumetric video
recorded with [Depthkit] to a [Visual Effect Graph].

[Depthkit]: https://www.depthkit.tv/
[Visual Effect Graph]: https://unity.com/visual-effect-graph

This project requires Unity 2019.2.
